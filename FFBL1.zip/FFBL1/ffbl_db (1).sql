-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Oct 02, 2022 at 04:29 PM
-- Server version: 8.0.30
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ffblevolvingtech_ffbl_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `admin_id` int NOT NULL,
  `name` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `status` int NOT NULL,
  `adminrole` int NOT NULL,
  `created_by` int NOT NULL,
  `created_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `name`, `password`, `status`, `adminrole`, `created_by`, `created_date`) VALUES
(3, 'admin', '$2y$10$jyPb.OXi0u/zx/jecrEGm.GO8KmWrTNE4tAs655uHHA14f8MWeesy', 1, 0, 1, '2022-09-29'),
(4, 'Shahfarhad', '$2y$10$MRymS74tnKyJUIpECyYBK.aKoFbC5tEn5wqZwEdmT3yE3gezS6Gui', 1, 1, 3, '2022-09-29'),
(6, 'shah', '$2y$10$vMdl4wQF7J55ueoLum6l/.T6Gj2Eel419jucnsbQrlJ3LtM7OTFaO', 1, 2, 3, '2022-10-01');

-- --------------------------------------------------------

--
-- Table structure for table `form`
--

CREATE TABLE `form` (
  `form_id` int NOT NULL,
  `form_name` varchar(200) NOT NULL,
  `type_id` int NOT NULL,
  `status` int NOT NULL,
  `created_by` int NOT NULL,
  `created_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `form`
--

INSERT INTO `form` (`form_id`, `form_name`, `type_id`, `status`, `created_by`, `created_date`) VALUES
(1, 'test form 1', 2, 1, 3, '2022-09-29'),
(2, 'Per-shift log sheet', 1, 1, 3, '2022-09-29'),
(3, '2-hours log sheet', 2, 1, 3, '2022-09-29'),
(4, 'Audit sheet', 3, 1, 3, '2022-09-29'),
(5, 'test', 3, 0, 3, '2022-09-30'),
(9, 'test form', 1, 1, 3, '2022-10-01');

-- --------------------------------------------------------

--
-- Table structure for table `form_data`
--

CREATE TABLE `form_data` (
  `form_data_id` int NOT NULL,
  `form_id` int DEFAULT NULL,
  `data_status` int NOT NULL,
  `created_by` int NOT NULL,
  `remarks1` varchar(500) DEFAULT NULL,
  `remarks2` varchar(500) DEFAULT NULL,
  `remarks3` varchar(500) DEFAULT NULL,
  `edited_by` int DEFAULT NULL,
  `created_date` date NOT NULL,
  `created_time` time DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `form_data`
--

INSERT INTO `form_data` (`form_data_id`, `form_id`, `data_status`, `created_by`, `remarks1`, `remarks2`, `remarks3`, `edited_by`, `created_date`, `created_time`) VALUES
(1, 9, 0, 3, 'morning', 'evening', 'Night', 3, '2022-10-02', '01:17:04'),
(2, 2, 0, 3, 'morning', 'evening', 'Night', 3, '2022-10-02', '01:25:26');

-- --------------------------------------------------------

--
-- Table structure for table `form_data_details`
--

CREATE TABLE `form_data_details` (
  `form_data_details_id` int NOT NULL,
  `form_data_id` int NOT NULL,
  `subform_detail_id` int NOT NULL,
  `form_data_value` varchar(200) NOT NULL,
  `entry_time` time DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `form_data_details`
--

INSERT INTO `form_data_details` (`form_data_details_id`, `form_data_id`, `subform_detail_id`, `form_data_value`, `entry_time`) VALUES
(40, 1, 14, '140', '00:00:00'),
(41, 1, 15, '241', '00:00:00'),
(42, 1, 14, '342', '02:19:00'),
(43, 1, 15, '443', '02:19:00'),
(44, 1, 14, '544', '04:24:00'),
(45, 1, 15, '645', '04:24:00'),
(46, 2, 3, '146', '00:25:00'),
(47, 2, 4, '247', '00:25:00'),
(48, 2, 5, '348', '00:25:00'),
(49, 2, 6, '449', '00:25:00'),
(50, 2, 7, '550', '00:25:00'),
(51, 2, 8, '651', '00:25:00'),
(52, 2, 9, '752', '00:25:00'),
(53, 2, 10, '853', '00:25:00'),
(54, 2, 11, '954', '00:25:00'),
(55, 2, 3, '1155', '02:25:00'),
(56, 2, 4, '2256', '02:25:00'),
(57, 2, 5, '3357', '02:25:00'),
(58, 2, 6, '4458', '02:25:00'),
(59, 2, 7, '5559', '02:25:00'),
(60, 2, 8, '6660', '02:25:00'),
(61, 2, 9, '7761', '02:25:00'),
(62, 2, 10, '8862', '02:25:00'),
(63, 2, 11, '9963', '02:25:00');

-- --------------------------------------------------------

--
-- Table structure for table `form_type`
--

CREATE TABLE `form_type` (
  `type_id` int NOT NULL,
  `type_name` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `form_type`
--

INSERT INTO `form_type` (`type_id`, `type_name`) VALUES
(1, 'Per-shift log sheet '),
(2, '2-hours log sheet'),
(3, 'Audit sheet');

-- --------------------------------------------------------

--
-- Table structure for table `operator`
--

CREATE TABLE `operator` (
  `operator_id` int NOT NULL,
  `operator_name` varchar(200) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL,
  `shift_id` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `operator`
--

INSERT INTO `operator` (`operator_id`, `operator_name`, `shift_id`) VALUES
(6, NULL, 1);

-- --------------------------------------------------------

--
-- Table structure for table `shift`
--

CREATE TABLE `shift` (
  `shift_id` int NOT NULL,
  `shift_name` varchar(200) NOT NULL,
  `from` varchar(50) DEFAULT NULL,
  `to` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `shift`
--

INSERT INTO `shift` (`shift_id`, `shift_name`, `from`, `to`) VALUES
(1, 'Morning', '8:00am', '4:00pm'),
(2, 'Evening', '4:00pm', '12:00am'),
(3, 'Night', '12:00am', '8:00am');

-- --------------------------------------------------------

--
-- Table structure for table `subform`
--

CREATE TABLE `subform` (
  `subform_id` int NOT NULL,
  `form_id` int NOT NULL,
  `subform_name` varchar(200) NOT NULL,
  `status` int NOT NULL,
  `created_by` int NOT NULL,
  `created_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `subform`
--

INSERT INTO `subform` (`subform_id`, `form_id`, `subform_name`, `status`, `created_by`, `created_date`) VALUES
(1, 1, 'sub form 1', 1, 3, '2022-09-29'),
(2, 2, 'Sub Form 1', 1, 3, '2022-09-29'),
(3, 2, 'Sub Form 2', 1, 3, '2022-09-29'),
(5, 1, 'sub form 2', 1, 3, '2022-10-01'),
(6, 9, 'test sub form', 1, 3, '2022-10-01'),
(7, 9, 'test sub form 1', 1, 3, '2022-10-02');

-- --------------------------------------------------------

--
-- Table structure for table `subform_detail`
--

CREATE TABLE `subform_detail` (
  `subform_detail_id` int NOT NULL,
  `subform_id` int NOT NULL,
  `description1` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL,
  `description2` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL,
  `bmr` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL,
  `range` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL,
  `status` int NOT NULL,
  `created_by` int NOT NULL,
  `created_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `subform_detail`
--

INSERT INTO `subform_detail` (`subform_detail_id`, `subform_id`, `description1`, `description2`, `bmr`, `range`, `status`, `created_by`, `created_date`) VALUES
(1, 1, 'ddg', 'gd', '34', '78', 1, 3, '2022-09-29'),
(2, 1, 'gsdg', 'dsfsd', 'r32', 'sdfsd24', 1, 3, '2022-09-29'),
(3, 2, 'E-1001A tube side inlet pressure', 'PI-1001', '38.6 kg/cm2', '35 ~ 40 kg/cm2', 1, 3, '2022-09-29'),
(4, 2, 'E-1001A tube side inlet temp.', 'TI-1001', '40 oC', '30 ~ 45 oC', 1, 3, '2022-09-29'),
(5, 2, 'E-1001A tube side outlet temp', 'TI-1002', '', '180 ~ 225oC', 1, 3, '2022-09-29'),
(6, 2, 'E-1001B tube side outlet temp', 'TI-1003', '325 oC', '300 ~ 340 oC', 1, 3, '2022-09-29'),
(7, 2, 'E-1001B tube side outlet pressure', 'PI-1002', '', '35 ~ 40 kg/cm2', 1, 3, '2022-09-29'),
(8, 2, 'F-1003 mix gas outlet temp.', 'TI-1051', '380 oC', '350 ~ 400 oC', 1, 3, '2022-09-29'),
(9, 2, 'PG flow to F-1003', 'FI-1048', '42876NMC/hr', '40000~45000 NMC/hr', 1, 3, '2022-09-29'),
(10, 3, 'Synthesis gas to F-1003', 'FIC-1001', '1207 NMC/hr', '1300 ~ 1420 NMC/hr', 1, 3, '2022-09-29'),
(11, 3, 'Controller output', 'FV-1001', '', '10 ~ 40 %', 1, 3, '2022-09-29'),
(12, 5, 'test 1', 'test 2', 'test 3', 'test 3', 1, 3, '2022-10-01'),
(13, 5, 'test 1', 'test 2', 'test 3', 'test 3', 1, 3, '2022-10-01'),
(14, 6, 'test 1', 'test 2', 'test 3', 'test 4', 1, 3, '2022-10-01'),
(15, 6, 'test 1', 'test 2', 'test 3', 'test 4', 1, 3, '2022-10-01'),
(16, 7, 'test 1', 'test 1', 'test 1', 'test 1', 1, 3, '2022-10-02'),
(17, 1, 'test 1', 'test 2', 'test 3', 'test 3', 1, 3, '2022-10-02');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `form`
--
ALTER TABLE `form`
  ADD PRIMARY KEY (`form_id`),
  ADD KEY `created_by` (`created_by`),
  ADD KEY `type_id` (`type_id`);

--
-- Indexes for table `form_data`
--
ALTER TABLE `form_data`
  ADD PRIMARY KEY (`form_data_id`),
  ADD KEY `form_id` (`form_id`),
  ADD KEY `created_by` (`edited_by`),
  ADD KEY `by` (`created_by`);

--
-- Indexes for table `form_data_details`
--
ALTER TABLE `form_data_details`
  ADD PRIMARY KEY (`form_data_details_id`),
  ADD KEY `form_data_id` (`form_data_id`),
  ADD KEY `subform_detail_id` (`subform_detail_id`);

--
-- Indexes for table `form_type`
--
ALTER TABLE `form_type`
  ADD PRIMARY KEY (`type_id`);

--
-- Indexes for table `operator`
--
ALTER TABLE `operator`
  ADD KEY `operator_id` (`operator_id`),
  ADD KEY `shift_id` (`shift_id`);

--
-- Indexes for table `shift`
--
ALTER TABLE `shift`
  ADD PRIMARY KEY (`shift_id`);

--
-- Indexes for table `subform`
--
ALTER TABLE `subform`
  ADD PRIMARY KEY (`subform_id`),
  ADD KEY `form_id` (`form_id`),
  ADD KEY `created_by` (`created_by`);

--
-- Indexes for table `subform_detail`
--
ALTER TABLE `subform_detail`
  ADD PRIMARY KEY (`subform_detail_id`),
  ADD KEY `subform_id` (`subform_id`),
  ADD KEY `created_by` (`created_by`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `admin_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `form`
--
ALTER TABLE `form`
  MODIFY `form_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `form_data`
--
ALTER TABLE `form_data`
  MODIFY `form_data_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `form_data_details`
--
ALTER TABLE `form_data_details`
  MODIFY `form_data_details_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=64;

--
-- AUTO_INCREMENT for table `form_type`
--
ALTER TABLE `form_type`
  MODIFY `type_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `shift`
--
ALTER TABLE `shift`
  MODIFY `shift_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `subform`
--
ALTER TABLE `subform`
  MODIFY `subform_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `subform_detail`
--
ALTER TABLE `subform_detail`
  MODIFY `subform_detail_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `form`
--
ALTER TABLE `form`
  ADD CONSTRAINT `form_ibfk_1` FOREIGN KEY (`type_id`) REFERENCES `form_type` (`type_id`),
  ADD CONSTRAINT `form_ibfk_6` FOREIGN KEY (`created_by`) REFERENCES `admin` (`admin_id`);

--
-- Constraints for table `form_data`
--
ALTER TABLE `form_data`
  ADD CONSTRAINT `form_data_ibfk_6` FOREIGN KEY (`form_id`) REFERENCES `form` (`form_id`),
  ADD CONSTRAINT `form_data_ibfk_7` FOREIGN KEY (`edited_by`) REFERENCES `admin` (`admin_id`),
  ADD CONSTRAINT `form_data_ibfk_9` FOREIGN KEY (`created_by`) REFERENCES `admin` (`admin_id`);

--
-- Constraints for table `form_data_details`
--
ALTER TABLE `form_data_details`
  ADD CONSTRAINT `form_data_details_ibfk_1` FOREIGN KEY (`form_data_id`) REFERENCES `form_data` (`form_data_id`),
  ADD CONSTRAINT `form_data_details_ibfk_2` FOREIGN KEY (`subform_detail_id`) REFERENCES `subform_detail` (`subform_detail_id`);

--
-- Constraints for table `operator`
--
ALTER TABLE `operator`
  ADD CONSTRAINT `operator_ibfk_2` FOREIGN KEY (`shift_id`) REFERENCES `shift` (`shift_id`);

--
-- Constraints for table `subform`
--
ALTER TABLE `subform`
  ADD CONSTRAINT `subform_ibfk_1` FOREIGN KEY (`form_id`) REFERENCES `form` (`form_id`),
  ADD CONSTRAINT `subform_ibfk_6` FOREIGN KEY (`created_by`) REFERENCES `admin` (`admin_id`);

--
-- Constraints for table `subform_detail`
--
ALTER TABLE `subform_detail`
  ADD CONSTRAINT `subform_detail_ibfk_1` FOREIGN KEY (`subform_id`) REFERENCES `subform` (`subform_id`),
  ADD CONSTRAINT `subform_detail_ibfk_6` FOREIGN KEY (`created_by`) REFERENCES `admin` (`admin_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
