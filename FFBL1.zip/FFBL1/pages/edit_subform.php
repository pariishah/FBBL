<?php 
$title="Sub Forms";
include ("../includes/header.php");

include "../includes/function.php";

if(isset($_GET["sf_id"] )){
    $subformid=$_GET["sf_id"];

    $stmt=$conn->prepare("SELECT * , form.form_id,form_name FROM `subform` LEFT JOIN form ON subform.form_id=form.form_id  where subform.subform_id =:sf_id ");  
    $stmt->bindParam(":sf_id",$subformid);     
    if($stmt->execute()){
       $row=$stmt->fetch();
       
    ?>

<div class="row">

     <div class="col-sm-12">
        <div class="card">
                    <div class="col-md-6">
                                <h5 class="mt-5">Please Enter Sub Forms Details</h5>
                                <hr>
                                <form rol="form" method="post">
                                <div class="form-group row">
                                        <label for="inputEmail3" class="col-sm-3 col-form-label">Form </label>
                                        <div class="col-sm-9">
                                        <select required class="form-control" id="exampleFormControlSelect1" name="f_id">
                                        <option value="<?php echo $row["form_id"];?>"><?php echo $row["form_name"];?></option>
                                            <option value="">----Select----</option>
                                         <?php
                                         getform();
                                      
                                         ?>
                                        </select>
                                        </div>
                                    </div>
                                    
                                    <div class="form-group row">
                                        <label for="inputEmail3" class="col-sm-3 col-form-label">Sub Form Name</label>
                                        <div class="col-sm-9">
                                            <input required type="text"  value="<?php echo $row["subform_name"];?>"  class="form-control" id="inputEmail3" placeholder="Name" name="name">
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="inputPassword3" class="col-sm-3 col-form-label">Status</label>
                                        <div class="col-sm-9">
                                            <select required  class="form-control" id="exampleFormControlSelect1" name="status">
                                            <option value="<?php echo $row["status"];?>"><?php
                                            if($row["status"]==1) echo "Enable";
                                            else echo "Disaple"?></option>
                                            <option value="">-----Select-----</option>
                                         <option value="1">Enable</option>
                                            <option value="0">Disaple</option>
                                        </select>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <div class="col-sm-10">
                                            <button name="submit" type="submit" class="btn  btn-primary">Save</button>
                                        </div>
                                    </div>
                                </form>
                            </div>

                            
        </div>
     </div>
</div>
                


<?php


?>



<?php 
include ("../includes/footer.php");
if(isset($_POST["submit"])){
$form=$_POST["f_id"];   
$name=$_POST["name"];
$status=$_POST["status"];
if($name!="" && $form!="" ){
   
    $fstmt=$conn->prepare("UPDATE `subform` SET  form_id=:form_id, subform_name=:subform_name, status=:status WHERE subform_id=:sf_id ");
    //INSERT INTO form(`form_name`,`type_id`,`status`,`created_by`,`created_date`) VALUES(:form_name,:form_type,:form_status,:created_by,:created_date)");
    $fstmt->bindParam(':sf_id',$subformid);
    $fstmt->bindParam(':form_id',$form);
    $fstmt->bindParam(':subform_name',$name);
  
    $fstmt->bindParam(':status',$status);
        if($fstmt->execute()){
            echo '<script>alert("Form Updated");
            window.location.href="subform_details.php?f_id='.$row["form_id"].'"
            </script>';
           
            
        }else{
            echo '<script>alert("Error in Updation");</script>';
            
        }
}   
    
else{
    ?>
    <script>alert("Please Complete Form!");</script>
    <?php
}
}
else{
    ?>
    <script>//alert("Form!");</script>
    <?php
}
    }
}
?>


