<?php 
ini_set('display_errors', '1');
 include "../includes/connect.php";
 //createConnection();
 if(isset($_POST["id"]) && $_POST['id']!=="")
 {
if($_POST["id"]==2){
 	$stmt=$conn->prepare('SELECT * FROM shift');
 	$stmt->execute();
 	$output = '<label for="inputEmail3" class="col-sm-3 col-form-label">Shift</label>
     <div class="col-sm-9">
     <select required class="form-control"  name="shift_id">
     <option value="">Select shift</option>
      ';
 	if($stmt->rowCount() > 0){
	while($row =$stmt->fetch())
 	{
 		$output .= '
								<option value="'.$row['shift_id'].'">'. $row['shift_name'] .'</option>
											
							
 		';
 	}
	$output .='</select>
						</div>';
 	echo $output;
 }
}
 }


 ?>