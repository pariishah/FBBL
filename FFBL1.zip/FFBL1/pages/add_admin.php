<?php 
$title="ADD ADMIN";
include ("../includes/header.php");

include "../includes/connect.php";
$role=$_SESSION["role"];
?>

<div class="row">

     <div class="col-sm-12">
        <div class="card">

                            <div class="col-md-6">
                                <h5 class="mt-5">Please Enter User Details</h5>
                                <hr>
                                <form rol="form" method="post">
                                    <div class="form-group row">
                                        <label for="inputEmail3" class="col-sm-3 col-form-label">User Name</label>
                                        <div class="col-sm-9">
                                            <input required type="text" class="form-control" id="inputEmail3" placeholder="User Name" name="name">
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="inputPassword3" class="col-sm-3 col-form-label">Password</label>
                                        <div class="col-sm-9">
                                            <input required type="password" class="form-control" id="inputPassword3" placeholder="Password" name="pass">
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="inputEmail3" class="col-sm-3 col-form-label">Role</label>
                                        <div class="col-sm-9">
                                        <select required class="form-control" onchange="load_details(this.value)"  name="role">
                                        <option value="">Select Role</option>
                                         <option value="0">Admin</option>
                                            <option value="1">Eng</option>
                                            <option value="2">Operator</option>
                                        </select>
                                        </div>
                                    </div>
                                    <div class="form-group row" id="detail">
						
						</div>
                                    <div class="form-group row">
                                        <div class="col-sm-10">
                                            <button name="Add" type="submit" class="btn  btn-primary">Submit</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
        </div>
     </div>
</div>
<script>

function load_details(id)
{	
 
$.ajax({
        url:"add-fetch-operator.php",
        method:"POST",
        data:{id:id},
//  dataType: "json",
        success:function(data)
  
        {
          console.log("test"+data);
            $("#detail").html(data);
        }
    });
        
         
    
}
</script>               






<?php 
include ("../includes/footer.php");
if(isset($_POST["Add"])){
    date_default_timezone_set("Asia/Karachi");
$user_name=$_POST["name"];
$password=$_POST["pass"];
$role=$_POST["role"];
$date=date("Y-m-d");
$created_by=$_SESSION["ffbladmin_id"];
$status=1;
if($user_name!="" && $password!="" && $role!=""){
      $opts03 = [ "cost" => 15 ];
    
// $password2 = password_hash($password, PASSWORD_BCRYPT, $opts03);
    $password2=password_hash($password, PASSWORD_DEFAULT);
    //$password2 = substr( $password2, 0, 60 );
    
    $stmt=$conn->prepare("INSERT INTO admin(`name`,`password`,`status`,`adminrole`,`created_by`,`created_date`) VALUES(:username,:password,:status,:role,:created_by,:created_date)");
    $stmt->bindParam(':username',$user_name);
    $stmt->bindParam(':password',$password2);
    $stmt->bindParam(':status',$status);
    $stmt->bindParam(':role',$role);
    $stmt->bindParam(':created_by',$created_by);
    $stmt->bindParam(':created_date',$date);
        if($stmt->execute()){
            if($role==2){
                $op_id=  $conn->lastInsertId();
                $shift_id=$_POST["shift_id"];
                $stmt=$conn->prepare("INSERT INTO `operator`(`operator_id`, `shift_id`) VALUES(:op_id,:shift_id)");
                $stmt->bindParam(':op_id',$op_id);
                $stmt->bindParam(':shift_id',$shift_id);
                    if($stmt->execute()){
                        ?>
                        <script>alert("User Added Successfully");</script>
                        <?php
                    }else{
                            ?>
                        <script>alert("Error in Insertion");</script>
                        <?php
                    }          
             }
        else{
            ?>
        <script>alert("User Added Successfully");</script>
        <?php
        }
        
        }else{
                ?>
            <script>alert("Error in Insertion");</script>
            <?php
        }
}    /*
    */
else{
    ?>
    <script>alert("Please Complete Form!");</script>
    <?php
}
}
?>


