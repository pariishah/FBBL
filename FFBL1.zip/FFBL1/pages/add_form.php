<?php 
$title="Add Forms";
include ("../includes/header.php");

include "../includes/function.php";
$role=$_SESSION["role"];
?>

<div class="row">

     <div class="col-sm-12">
        <div class="card">
                    <div class="col-md-6">
                                <h5 class="mt-5">Please Enter Forms Details</h5>
                                <hr>
                                <form rol="form" method="post">
                                    <div class="form-group row">
                                        <label for="inputEmail3" class="col-sm-3 col-form-label">Form Name</label>
                                        <div class="col-sm-9">
                                            <input required type="text" class="form-control" id="inputEmail3" placeholder="Name" name="name">
                                        </div>
                                    </div>
                                   
                                    <div class="form-group row">
                                        <label for="inputEmail3" class="col-sm-3 col-form-label">Form Type</label>
                                        <div class="col-sm-9">
                                        <select required class="form-control" id="exampleFormControlSelect1" name="type">
                                        <option value="">----Select----</option>
                                        <?php
                                         getformtype();
                                      
                                         ?>
                                        </select>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="inputPassword3" class="col-sm-3 col-form-label">Status</label>
                                        <div class="col-sm-9">
                                            <select required class="form-control" id="exampleFormControlSelect1" name="status">
                                        <option value="">-----Select-----</option>
                                         <option value="1">Enable</option>
                                            <option value="0">Disaple</option>
                                        </select>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <div class="col-sm-10">
                                            <button name="submit" type="submit" class="btn  btn-primary">Submit</button>
                                        </div>
                                    </div>
                                </form>
                            </div>

                            
        </div>
     </div>
</div>
                






<?php 
include ("../includes/footer.php");
if(isset($_POST["submit"])){
    
    date_default_timezone_set("Asia/Karachi");
$name=$_POST["name"];
$type=$_POST["type"];
$status=$_POST["status"];
$date=date("Y-m-d");
$created_by=$_SESSION["ffbladmin_id"];

if($name!="" && $type!="" ){
   
    $fstmt=$conn->prepare("INSERT INTO form(`form_name`,`type_id`,`status`,`created_by`,`created_date`) VALUES(:form_name,:form_type,:form_status,:created_by,:created_date)");
    $fstmt->bindParam(':form_name',$name);
    $fstmt->bindParam(':form_type',$type);
    $fstmt->bindParam(':form_status',$status);
    $fstmt->bindParam(':created_by',$created_by);
    $fstmt->bindParam(':created_date',$date);
        if($fstmt->execute()){
            echo '<script>alert("Form Added Successfully");</script>';
            
        }else{
            echo '<script>alert("Error in Insertion");</script>';
            
        }
}   
    
else{
    ?>
    <script>alert("Please Complete Form!");</script>
    <?php
}
}
else{
    ?>
    <script>//alert("Form!");</script>
    <?php
}
?>


