<?php 
ini_set('display_errors', '1');
 include "../includes/connect.php";
 //createConnection();
 if(isset($_POST["time"]) && $_POST['time']!=="")
 {
$time=$_POST["time"];

 	$output = $time;
 	
 	echo $output;
 }


 ?>