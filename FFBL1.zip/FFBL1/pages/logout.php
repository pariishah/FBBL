<?php
    require_once '../includes/function.php';
    //my_session_start();
    session_start();
    echo "logout";
    logout();
?>