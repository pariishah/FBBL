<?php 
$title="Sub Forms Details";
include ("../includes/header.php");
include ("../includes/function.php");
if(isset($_GET["f_id"] )){
    $formid=$_GET["f_id"];

?>
     <!-- [ Main Content ] start -->
     <div class="row">
           
                              <div class="col-xl-12">
                <div class="card">
                    <div class="card-header">
                        <h5>Sub Form Details </h5>
                        <span class="d-block m-t-5"></span>
                    </div>
                    <div class="card-body table-border-style">
                        <div class="table-responsive">
                            <table class="table table-hover">
                                              <thead>
                                                  <tr>
                                                      <th>S-No</th>
                                                      <th>Sub Form Name</th>
                                                      <th>Status</th> 
                                                      <th>Created By</th>
                                                      <th>Created Date</th>
                                                      <th class="text-right">Add Headings</th>
                                                      <th class="text-right">Edit</th>
                                                      <th class="text-right">View</th>
                                                  </tr>
                                              </thead>
                                              <tbody>
                                             <?php 
                                            date_default_timezone_set("Asia/Karachi");
                                            $date=date("Y-m-d");
                                            $stmt=$conn->prepare("SELECT  subform.* , admin.name  FROM `subform` LEFT JOIN admin ON subform.created_by=admin.admin_id LEFT JOIN form ON subform.form_id=form.form_id where subform.form_id= :f_id  ");  
                                            
                                            $stmt->bindParam(":f_id",$formid);
                                            $stmt->execute();
                                            if($stmt->rowCount() > 0){
                                                $i=1;
                                               // echo '<script>alert("Error in Insertion");</script>';
                                                while ($row=$stmt->fetch())
                                                {
                                                    ?>
                                                                       <tr>
                                                                        <td><?php echo $i ;?></td>
                                                                                <td><?php echo $row["subform_name"];?></td>
                                                                                <td><?php if($row["status"] == 1){
                                                                                    echo "Enable";}
                                                                                    else
                                                                                    {
                                                                                        echo "Disaple";}
                                                                                    ?></td> 
                                                                                    
                                                                                    
                                                                                    <td><?php echo $row["name"];?></td>
                                                                                    <td><?php echo $row["created_date"];?></td>
                                                                                <td class="text-right"><a class="btn  btn-primary" href="add_subform_detail.php?subform_id=<?php echo $row["subform_id"];?>">Add </a>
                                                                              </td>
                                                                              <td class="text-right"><a class="btn  btn-primary" href="edit_subform.php?sf_id=<?php echo $row["subform_id"];?>">Edit</a>
                                                                              </td>
                                                                              <td class="text-right"><a class="btn  btn-primary" href="subform_details_view.php?sf_id=<?php echo $row["subform_id"];?>">View</a>
                                                                              </td>
                                                                            </tr>
                                             <?php
                                              
                                              $i++;  }
                                            }
                                             
                                             ?>
                                              </tbody>
                                          </table>
                                      </div>
                                  </div>
                              </div>
                                            </div>
                                                       
           
        </div>

<?php 
}
include ("../includes/footer.php");
?>