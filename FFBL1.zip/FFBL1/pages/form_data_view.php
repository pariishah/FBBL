<?php 
$title="Forms Details";
include ("../includes/header.php");
include ("../includes/function.php");
?>
     <!-- [ Main Content ] start -->
     <div class="row">
           
           <?php 
           if(($_SESSION["role"])!= 2)
                               {
                              ?>
                              <div class="col-xl-12">
                <div class="card">
                    <div class="card-header">
                        <h5>Forms Details </h5>
                        <span class="d-block m-t-5"></span>
                    </div>
                    <div class="card-body table-border-style">
                        <div class="table-responsive">
                            <table class="table table-hover">
                                              <thead>
                                                  <tr>
                                                      <th>S-No</th>
                                                      <th>Form Name</th>
                                                      <th>Status</th>  
                                                      <th>Created By</th>
                                                      <th>Created Date</th>
                                                      <th class="text-right">Edit</th>
                                                      <th class="text-right">View</th>
                                                  </tr>
                                              </thead>
                                              <tbody>
                                             <?php 
                                            date_default_timezone_set("Asia/Karachi");
                                            $date=date("Y-m-d");
                                            if(($_SESSION["role"]) == 0)
                                            {
                                                $stmt=$conn->prepare("SELECT  form.form_id,form_name , form_data.* , admin.name FROM `form_data` LEFT JOIN admin ON form_data.created_by=admin.admin_id LEFT JOIN form ON form_data.form_id=form.form_id  ");  
                                                
                                            }
                                            else if(($_SESSION["role"])== 1)
                                            {
                                                $status=1;
                                                $stmt=$conn->prepare("SELECT  form.form_id,form_name , form_data.* , admin.name FROM `form_data` LEFT JOIN admin ON form_data.created_by=admin.admin_id LEFT JOIN form ON form_data.form_id=form.form_id  where  form_data.data_status = :status");  
                                                  $stmt->bindParam(':status',$status);
                                                  
                                            }
                                            else{
                                                ?>
                                                <script>
                                                        window.location.href="index.php";
                                              </script>
                                            <?php

                                            }
                                            $stmt->execute();
                                            if($stmt->rowCount() > 0){
                                                $i=1;
                                               // echo '<script>alert("Error in Insertion");</script>';
                                                while ($row=$stmt->fetch())
                                                {
                                                    ?>
                                                                       <tr>
                                                                        <td><?php echo $i ;?></td>
                                                                                <td><?php echo $row["form_name"];?></td>
                                                                                <td><?php if($row["data_status"] == 1){
                                                                                     echo "Draft";}
                                                                                     else {
                                                                                         echo "Verified";}
                                                                                ?></td> 
                                                                                    
                                                                                    <td><?php echo $row["name"];?></td>
                                                                                    <td><?php echo $row["created_date"];?></td>
                                                                                
                                                                                    <td class="text-right"><a class="btn  btn-primary" href="update_formdata.php?f_id=<?php echo $row["form_id"];?>&& form_name=<?php echo $row["form_name"];?>&&form_data_id=<?php echo $row["form_data_id"];?>">Edit</a>
                                                                                </td>
                                                                              <td class="text-right"><a class="btn  btn-primary" href="form_data_view.php">View</a>
                                                                              </td>
                                                                            </tr>
                                             <?php
                                              
                                              $i++;  }
                                            }
                                             
                                             ?>
                                              </tbody>
                                          </table>
                                      </div>
                                  </div>
                              </div>
                                            </div>
                                            
                                            <?php
                               }
                               ?>
            
           
        </div>

<?php 
include ("../includes/footer.php");
?>