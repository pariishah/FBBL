
<?php 
$title="Log Sheets";
include ("../includes/header.php");
include "../includes/function.php";

$time="";
?>
<style>
input[type=text].noborder {
  width: 100%;
  box-sizing: border-box;
  border: 0px solid #ccc;
  -webkit-transition: 0.5s;
  transition: 0.5s;
  outline: none;
}

input[type=text]:focus.noborder {
  border: 2px solid #00b386;
}
    
    </style>
<div class="row">

                
            <!-- [ basic-table ] start -->
            <?php
if(isset($_GET["data_no"] ) && isset($_GET["f_id"] )){
    
    date_default_timezone_set("Asia/Karachi");
    $date=date("Y-m-d");
$f_id=$_GET["f_id"];
$data_no=$_GET["data_no"];

//$time=$_POST["time"];
$stmt=$conn->prepare("SELECT subform.subform_id,subform.subform_name FROM `subform`  where form_id= :f_id");  
    //$stmt->bindParam(':created_date',$date);
    $stmt->bindParam(":f_id",$f_id); 
    $stmt->execute();
    	if($stmt->rowCount() > 0){
            while ($row=$stmt->fetch())
    		{
            ?>
                <div class="col-md-6">
                <div class="card">
                    <div class="card-header">
                        <h5><?php echo $row['subform_name'];?></h5>
                    </div>
                    <div class="card-body table-border-style">
                        <div class="table-responsive">
                            <table style="width:100%" class="table">
                                <thead>
                                    <?php
                                    $substmt=$conn->prepare("SELECT subform_detail.* , form_data.*  FROM `form_data` LEFT JOIN subform_detail ON form_data.subform_detail_id=subform_detail.subform_detail_id where subform_detail.subform_id= :f_id And form_data.data_no= :data_no");  
                                    //$stmt->bindParam(':created_date',$date);
                                    $substmt->bindParam(":f_id",$row['subform_id']); 
                                    $substmt->bindParam(":data_no",$data_no);
                                    $substmt->execute();
                                        if($substmt->rowCount() > 0 ){
                                            $data=$substmt->rowCount();
                                           // $row2=$substmt->fetch();
                                            //$row=$stmt->fetch();
                                            //$time=$row2['entry_time'];
                                            ?>
                                            <tr>
                                            <th><span class="d-block m-t-5" style="color: red;">Description</span>
                                        <span class="d-block m-t-5" style="color: blue;"> <br></span>
                                        <span class="d-block m-t-5" style="color: black;">BMR Value</span>
                                        <span class="d-block m-t-5" style="color: green;">Operating Range</span>
                                    </th>
                                                <?php
                                            while ($row1=$substmt->fetch() )
                                            {
                                                $time=$row1['entry_time'];   
                                                ?> 
                                                
                                               
                                           <th><span class="d-block m-t-5" style="color: red;"><?php echo $row1['description1'];?></span>
                                        <span class="d-block m-t-5" style="color: blue;"> <?php echo $row1['description2'];?></span>
                                       <?php if( $row1['bmr']==""){
                                        echo '<span class="d-block m-t-5" style="color: black;"><br> </span>';

                                        }?>
                                        <span class="d-block m-t-5" style="color: black;"><?php echo $row1['bmr'];?></span>
                                        <span class="d-block m-t-5" style="color: green;"><?php echo $row1['range'];?></span>

                                    </th> 
                                    <?php
                                            } 
                                            ?>
                                            </thead>
                                <tbody>
                                <form rol="form" method="post">
                                    <?php
                                            $substmt2=$conn->prepare("SELECT subform_detail.* , form_data.*  FROM `form_data` LEFT JOIN subform_detail ON form_data.subform_detail_id=subform_detail.subform_detail_id where subform_detail.subform_id= :f_id And form_data.data_no= :data_no");  
                                    //$stmt->bindParam(':created_date',$date);
                                    $substmt2->bindParam(":f_id",$row['subform_id']); 
                                    $substmt2->bindParam(":data_no",$data_no);
                                    $substmt2->execute();
                                    if($substmt2->rowCount() > 0 ){
                                       // echo '<script type="text/javascript">alert("Execute Javascript Function Through PHP");</script>';
                                       ?>
                                            <td><?php echo $time;?></td>
                                    <?php
                                            while ($row1=$substmt2->fetch() )
                                            {
                                                echo '<td> <input required type="text" value="'.$row1['form_data_value'].'"  id="inputEmail3" class="noborder" placeholder="Enter Value---" name="value[]"</td>';
                                               ?>
                                                <input type="hidden" value="<?php echo $row1["form_data_id"];?>" class="form-control mt-1" name="form_data_id[]">
                                    <?php
                                            }
                                        }

                                            ?>
                                            
                                <?php
                                        }?>
                                            </tr>                                          
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

                                <?php
    		
            
        }
        
    }
    ?>
    <br>
    <div class="col-sm-12">
                  <div class="card">
                        <div class="col-md-6"> <br>
                                <div class="form-group row">
                                   <label for="inputEmail3" class="col-sm-3 col-form-label"><b>Remarks</b> </label>
                                   <div class="col-sm-9">
                                   <input  type="text" style="width:1100px ;" class="form-control" id="time" placeholder="Remarks" name="remarks">
                                   </div>
                                </div>
     <div class="form-group row">
                                   <div class="col-sm-10">
                                       <button name="add" type="submit" class="btn  btn-primary">Submit</button>
                                   </div>
                                   </div>
                     </div>
                </div> </form> 
                <?php
}
    ?>
           
</div>

<?php 
include ("../includes/footer.php");
?>


<?php
if(isset($_POST["add"])){
    
    date_default_timezone_set("Asia/Karachi");
    $count=count($_POST["form_data_id"]);
$form_data_id=$_POST["form_data_id"];
$value=$_POST["value"];
$remarks=$_POST["remarks"];
$edited_by=$_SESSION["ffbladmin_id"];
$status=0;
$data_no=getform_data_no($count);


for ($i=0; $i <$count ; $i++) { 
   
    $stmt=$conn->prepare("UPDATE `form_data` SET form_data_value=:value, data_status=:status, edited_by=:edited_by WHERE form_data_id=:form_data_id ");
    $stmt->bindParam(":value",$value[$i]);
    $stmt->bindParam(":status",$status);
    $stmt->bindParam(':edited_by',$edited_by);
    $stmt->bindParam(":form_data_id",$form_data_id[$i]);
    $stmt->execute();
    }
    ?>
    <script>
    alert("Updated Successfully");
            //alert("Patient added successfully");
    
            window.location.href="index.php";
  </script>
<?php
}
    ?>


<?php
date_default_timezone_set("Asia/Karachi");
$time = date('2022-09-29 06:16:30');
function timeago($time, $tense='ago'){
 static $periods = array('year','month','day','hour','minute','second');
 if(!(strtotime($time)>0)){
    return trigger_error("wrong time format: '$time'",E_USER_ERROR);
     }
     $now = new DateTime(('now'));
     $time = new DateTime($time);
     $diff = $now->diff($time)->format('%y %m %d %h %i %s');
     $diff = explode(' ', $diff);
     //echo $diff;
     $diff = array_combine($periods,$diff);
     $diff = array_filter($diff);
    

     $periods = key($diff);

     $value = current($diff);
     if(!$value){
        $periods ='';
        $tense = '';
        $value = 'just now';
     }
     else{
        if($periods == 'day' && $value >=7){
            $periods= 'week';
            $value = floor($value/7);
        }
        if($value > 1){
            $periods.='s';
        }
     }
     return "$value $periods $tense";

}
$timeago = timeago($time);
$date=date("Y-m-d ");
//echo $date;
//echo $timeago;
?>
