<?php 
$title="Sub Forms Details";
include ("../includes/header.php");
include ("../includes/function.php");
if(isset($_GET["sf_id"] )){
    $subformid=$_GET["sf_id"];

?>
     <!-- [ Main Content ] start -->
     <div class="row">
           
                              <div class="col-xl-12">
                <div class="card">
                    <div class="card-header">
                        <h5>Sub Form Headings </h5>
                        <span class="d-block m-t-5"></span>
                    </div>
                    <div class="card-body table-border-style">
                        <div class="table-responsive">
                            <table class="table table-hover">
                                              <thead>
                                                  <tr>
                                                      <th>S-No</th>
                                                      <th>Description 1</th>
                                                      <th>Description 2</th>
                                                      <th>BMR Value</th>
                                                      <th>Operating Range</th>
                                                      <th>Status</th> 
                                                      <th>Created By</th>
                                                      <th>Created Date</th>
                                                      <th class="text-right">Edit</th>
                                                  </tr>
                                              </thead>
                                              <tbody>
                                             <?php 
                                            date_default_timezone_set("Asia/Karachi");
                                            $date=date("Y-m-d");
                                            $stmt=$conn->prepare("SELECT  subform_detail.* , admin.name  FROM `subform_detail` LEFT JOIN admin ON subform_detail.created_by=admin.admin_id LEFT JOIN subform ON subform_detail.subform_id=subform.subform_id where subform_detail.subform_id= :sf_id  ");  
                                            
                                            $stmt->bindParam(":sf_id",$subformid);
                                            $stmt->execute();
                                            if($stmt->rowCount() > 0){
                                                $i=1;
                                               // echo '<script>alert("Error in Insertion");</script>';
                                                while ($row=$stmt->fetch())
                                                {
                                                    ?>
                                                                       <tr>
                                                                        <td><?php echo $i ;?></td>
                                                                                <td><?php echo $row["description1"];?></td>
                                                                                <td><?php echo $row["description2"];?></td>
                                                                                <td><?php echo $row["bmr"];?></td>
                                                                                <td><?php echo $row["range"];?></td>
                                                                                <td><?php if($row["status"] == 1){
                                                                                    echo "Enable";}
                                                                                    else
                                                                                    {
                                                                                        echo "Disaple";}
                                                                                    ?></td>                                                                                    
                                                                                    
                                                                                    <td><?php echo $row["name"];?></td>
                                                                                    <td><?php echo $row["created_date"];?></td>
                                                                                
                                                                              <td class="text-right"><a class="btn  btn-primary" href="edit_subform_details.php?f_id=<?php echo $row["subform_detail_id"];?>">Edit</a>
                                                                              </td>
                                                                            </tr>
                                             <?php
                                              
                                              $i++;  }
                                            }
                                             
                                             ?>
                                              </tbody>
                                          </table>
                                      </div>
                                  </div>
                              </div>
                                            </div>
                                                       
           
        </div>

<?php 
}
include ("../includes/footer.php");
?>