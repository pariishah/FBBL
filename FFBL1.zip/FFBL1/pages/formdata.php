
<?php 
$title="Log Sheets";
include ("../includes/header.php");
include "../includes/function.php";

$time="";
$f_id=0;
date_default_timezone_set("Asia/Karachi");
    $date=date("Y-m-d");
    $inserttype=false;
    $form_data_id=0;
?>
<style>
input[type=text].noborder {
  width: 100%;
  box-sizing: border-box;
  border: 0px solid #ccc;
  -webkit-transition: 0.5s;
  transition: 0.5s;
  outline: none;
}

input[type=text]:focus.noborder {
  border: 2px solid #00b386;
}
    
    </style>
<div class="row">

                <div class="col-sm-12">
                  <div class="card">
                        <div class="col-md-6">
                           <h5 class="mt-5">Please Select Forms Details</h5>
                           <hr>
                           <form rol="form" method="post">
                             <div class="form-group row">
                                   <label for="inputEmail3" class="col-sm-3 col-form-label">Form Name </label>
                                   <div class="col-sm-9">
                                   <select required id="form" class="form-control" id="exampleFormControlSelect1" name="f_id">
                                   <option value="">----Select----</option>
                                    <?php
                                    getform();
                                 
                                    ?>
                                   </select>
                                   </div>
                                </div>
                                <div class="form-group row">
                                   <label for="inputEmail3" class="col-sm-3 col-form-label">Form Name </label>
                                   <div class="col-sm-9">
                                   <input required type="time" class="form-control" id="time" placeholder="Name" name="time">
                                   </div>
                                </div>
                                
                               <div class="form-group row">
                                   <div class="col-sm-10">
                                       <button name="submit" type="submit" class="btn  btn-primary">Submit</button>
                                   </div>
                               </div>
                           </form>
                       </div>
                     </div>
                </div>
            <!-- [ basic-table ] start -->
            <?php
if(isset($_POST["submit"])){
    
    date_default_timezone_set("Asia/Karachi");
    $date=date("Y-m-d");
$f_id=$_POST["f_id"];
//$form_id=$f_id;
//echo '<script>alert("'.$form_id.'");</script>';
$time=$_POST["time"];
$stmt=$conn->prepare("SELECT subform.subform_id,subform.subform_name FROM `subform`  where form_id= :f_id");  
    //$stmt->bindParam(':created_date',$date);
    $stmt->bindParam(":f_id",$f_id); 
    $stmt->execute();
    	if($stmt->rowCount() > 0){
            while ($row=$stmt->fetch())
    		{
            ?>
                <div class="col-md-6">
                <div class="card">
                    <div class="card-header">
                        <h5><?php echo $row['subform_name'];?></h5>
                    </div>
                    <div class="card-body table-border-style">
                        <div class="table-responsive">
                            <table style="width:100%" class="table">
                                <thead>
                                    <?php
                                    $substmt=$conn->prepare("SELECT * FROM `subform_detail`  where subform_id= :f_id");  
                                    //$stmt->bindParam(':created_date',$date);
                                    $substmt->bindParam(":f_id",$row['subform_id']); 
                                    $substmt->execute();
                                        if($substmt->rowCount() > 0){
                                            $data=$substmt->rowCount();
                                            ?>
                                            <tr>
                                            <th><span class="d-block m-t-5" style="color: red;">Description</span>
                                        <span class="d-block m-t-5" style="color: blue;"> <br></span>
                                        <span class="d-block m-t-5" style="color: black;">BMR Value</span>
                                        <span class="d-block m-t-5" style="color: green;">Operating Range</span>
                                    </th><form rol="form" method="post">
                                                <?php
                                            while ($row1=$substmt->fetch())
                                            {

                                                ?>
                                                <input type="hidden" value="<?php echo $row1["subform_detail_id"];?>" class="form-control mt-1" name="sub_detail_id[]">
                                           <th><span class="d-block m-t-5" style="color: red;"><?php echo $row1['description1'];?></span>
                                        <span class="d-block m-t-5" style="color: blue;"> <?php echo $row1['description2'];?></span>
                                       <?php if( $row1['bmr']==""){
                                        echo '<span class="d-block m-t-5" style="color: black;"><br> </span>';

                                        }?>
                                        <span class="d-block m-t-5" style="color: black;"><?php echo $row1['bmr'];?></span>
                                        <span class="d-block m-t-5" style="color: green;"><?php echo $row1['range'];?></span>
                                    </th> 
                                    <?php
                                            }?>
                                            </tr>                                           
                                    
                                </thead>
                                <tbody>
                                <?php
                                            $substmt2=$conn->prepare("SELECT  form_data.*, form_data_details.*  FROM `form_data_details` LEFT JOIN form_data ON form_data_details.form_data_id = form_data.form_data_id LEFT JOIN subform_detail ON form_data_details.subform_detail_id =subform_detail.subform_detail_id  where  form_data.form_id= :form_id And form_data.created_date =  :created_date And subform_detail.subform_id = :subform_id ORDER BY `form_data_details`.`entry_time` ASC");  
                                    //$stmt->bindParam(':created_date',$date);
                                    $substmt2->bindParam(":subform_id",$row['subform_id']); 
                                    $substmt2->bindParam(":form_id",$f_id);//
                                    $substmt2->bindParam(":created_date",$date);
                                    $substmt2->execute();
                                    //echo '<script type="text/javascript">alert("'.$date.'");</script>';
                                    if($substmt2->rowCount() > 0 ){
                                        $inserttype=true;
                                        $row1=$substmt2->fetch();
                                      //  $form_data_id=$row1['form_data_id'];
                                        
                                      // echo '<script type="text/javascript">alert("Execute Javascript Function Through PHP");</script>';
                                       ?>
                                            <tr><td><?php echo $row1['entry_time'];?></td>
                                            <input type="hidden" value="<?php echo $row1['form_data_id'];?>" class="form-control mt-1" name="form_data_id">
                                    <?php
                                    echo '<td> '.$row1['form_data_value'].'</td>';
                                    $entry=$row1['entry_time'];
                                            while ($row1=$substmt2->fetch() )
                                            {
                                                if($row1['entry_time']==$entry){
                                                    echo '<td> '.$row1['form_data_value'].'</td>';
                                                }
                                                else{
                                                    echo '<tr><td> '.$row1['entry_time'].'</td>';
                                                    echo '<td> '.$row1['form_data_value'].'</td>';
                                                    $entry=$row1['entry_time'];
                                                }
                                                
                                               }
                                        }
                                        else{
                                            $inserttype=false;  
                                        }
                                        ?>
                                            </tr> 
                                
                                    <tr>
                                        <td><?php echo $time;?></td><input type="hidden" value="<?php echo $time;?>" class="form-control mt-1" name="time">
                                        <input type="hidden" value="<?php echo $f_id;?>" class="form-control mt-1" name="f_id">
                                        <?php
                                        for($i=1;$i<=$data;$i++){
                                            echo '<td> <input required type="text"  id="inputEmail3" class="noborder" placeholder="Enter Value---" name="value[]">';
                                        }

                                        ?>
<?php                                          
                                              
                                            }
                                            ?>
                                        
                                   
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

                                <?php
    		
            
        }
        
    }
    ?>
    <br>
    <div class="col-sm-12">
                  <div class="card">
                        <div class="col-md-6"> <br>
                               
     <div class="form-group row">
                                   <div class="col-sm-10">
                                       <button name="add" type="submit" class="btn  btn-primary">Submit</button>
                                   </div>
                                   </div>
                     </div>
                </div> </form> 
                <?php
}
    ?>
           
</div>

<?php 
include ("../includes/footer.php");
?>


<?php
if(isset($_POST["add"])){
   
    
    $count=count($_POST["sub_detail_id"]);
$sub_detail_id=$_POST["sub_detail_id"];
$value=$_POST["value"];
$time=$_POST["time"];
$f_id=$_POST["f_id"];
$remarks=$_POST["remarks"];
$created_time=date("h:i:s");
$created_by=$_SESSION["ffbladmin_id"];
$status=1;
$form_data_id=$_POST["form_data_id"];
echo '<script>
alert("'.$form_data_id.'");

</script>';
echo '<script>
alert("'.$count.'");

</script>';
if($form_data_id !=""){
    
    $data_id=  $form_data_id;
    for ($i=0; $i <$count ; $i++) { 
        $stmt=$conn->prepare("INSERT INTO `form_data_details`(`form_data_id`, `subform_detail_id`, `form_data_value`,`entry_time`) VALUES (:f_data_id,:sub_detail_id,:value,:time)");
        $stmt->bindParam(":f_data_id",$data_id);
         $stmt->bindParam(":sub_detail_id",$sub_detail_id[$i]);
        $stmt->bindParam(":value",$value[$i]);
        $stmt->bindParam(":time",$time);
       if($stmt->execute()) {
       
       }
       
   
    }
    ?>
    <script>alert("Data Added Successfully ");</script>
    <?php
    
}
else{
$stmt=$conn->prepare("INSERT INTO `form_data`( `form_id`, `data_status`, `created_by`,  `created_date`, `created_time`) VALUES (:f_id,:status,:created_by,:created_date,:created_time)");
$stmt->bindParam(":f_id",$f_id);
$stmt->bindParam(":status",$status);
$stmt->bindParam(':created_by',$created_by);
$stmt->bindParam(':created_date',$date);
$stmt->bindParam(':created_time',$created_time);
//$stmt->execute();
if($stmt->execute())
{
    $data_id=  $conn->lastInsertId();

    for ($i=0; $i <$count ; $i++) { 
        $stmt=$conn->prepare("INSERT INTO `form_data_details`(`form_data_id`, `subform_detail_id`, `form_data_value`,`entry_time`) VALUES (:f_data_id,:sub_detail_id,:value,:time)");
        $stmt->bindParam(":f_data_id",$data_id);
         $stmt->bindParam(":sub_detail_id",$sub_detail_id[$i]);
        $stmt->bindParam(":value",$value[$i]);
        $stmt->bindParam(":time",$time);
        $stmt->execute();
   
   
    }
    ?>
<script>alert("Data Added Successfully");</script>
<?php
}
else{
    ?>
<script>alert("Error in Insertion");</script>
<?php
}
}
    ?>
    <script>
   // alert("Added Successfully");
   
  </script>
<?php  
}
?>
