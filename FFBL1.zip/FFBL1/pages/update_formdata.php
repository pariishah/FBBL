
<?php 
$title="Log Sheets";
include ("../includes/header.php");
include "../includes/function.php";

$time="";
?>
<style>
input[type=text].noborder {
  width: 100%;
  box-sizing: border-box;
  border: 0px solid #ccc;
  -webkit-transition: 0.5s;
  transition: 0.5s;
  outline: none;
}

input[type=text]:focus.noborder {
  border: 2px solid #00b386;
}
    
    </style>
     <?php
if(isset($_GET["form_data_id"] ) && isset($_GET["f_id"] )){
    
    date_default_timezone_set("Asia/Karachi");
    $date=date("Y-m-d");
$f_id=$_GET["f_id"];
$form_name=$_GET["form_name"];
$form_data_id=$_GET["form_data_id"];//SELECT  form.form_id,form_name , form_data.* FROM `form_data` LEFT JOIN form ON form_data.form_id=form.form_id  where form_data.created_date = :created_date
$remarks1="";
$remarks2="";
$remarks3="";
$stmt=$conn->prepare("SELECT  form_data.*, subform.subform_id,subform_name FROM `form_data` LEFT JOIN form ON form_data.form_id=form.form_id LEFT JOIN subform ON form.form_id =subform.form_id where form_data.form_id= :f_id and form_data.form_data_id = :form_data_id");  
    $stmt->bindParam(":f_id",$f_id); 
    $stmt->bindParam(":form_data_id",$form_data_id);
    $stmt->execute();
    	if($stmt->rowCount() > 0){
            ?>
            <div class="row">
                <div class="col-sm-12">
                    <div class="card">
                        <div style="text-align: center;" class="card-header">
                            <h5 style="text-align: center;"><?php echo $form_name;?></h5>
                        </div>                            
                    </div>   
                </div>
                <?php

            while ($row=$stmt->fetch())
    		{
                $remarks1=$row['remarks1'];
                $remarks2=$row['remarks2'];
                $remarks3=$row['remarks3'];
                ?>     
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header">
                        <h5><?php echo $row['subform_name'];?></h5>
                    </div>
                    <div class="card-body table-border-style">
                        <div class="table-responsive">
                            <table style="width:100%" class="table">
                                <thead>
                                   <?php
                                   $stmt1=$conn->prepare("SELECT subform_detail.* FROM `subform_detail` LEFT JOIN subform ON subform_detail.subform_id=subform.subform_id where subform_detail.subform_id=:subform_id");  
                                   $stmt1->bindParam(":subform_id",$row['subform_id']);
                                   //$stmt1->bindParam(":form_data_id",$form_data_id);
                                   $stmt1->execute();
                                       if($stmt1->rowCount() > 0){
                                        ?> 
                                    <tr>
                                            <th><span class="d-block m-t-5" style="color: red;">Description</span>
                                        <span class="d-block m-t-5" style="color: blue;"> <br></span>
                                        <span class="d-block m-t-5" style="color: black;">BMR Value</span>
                                        <span class="d-block m-t-5" style="color: green;">Operating Range</span>
                                    </th>

                                    <?php
                                    while ($row1=$stmt1->fetch())
                                    {
                                        ?>  
                                     
                                         <th><span class="d-block m-t-5" style="color: red;"><?php echo $row1['description1'];?></span>
                                        <span class="d-block m-t-5" style="color: blue;"> <?php echo $row1['description2'];?></span>
                                        <?php if( $row1['bmr']==""){
                                        echo '<span class="d-block m-t-5" style="color: black;"><br> </span>';

                                        }?>
                                        <span class="d-block m-t-5" style="color: black;"><?php echo $row1['bmr'];?></span>
                                        <span class="d-block m-t-5" style="color: green;"><?php echo $row1['range'];?></span>
                                        

                                    </th> 
                                    <?php
                                    }
                                      ?></tr>
                                      <?php 
                                       ?>
                                       </thead>
                                       
                                       <form rol="form" method="post">
                                       
                                        <?php
                                     $stmt2=$conn->prepare("SELECT subform_detail.*, form_data_details.* FROM `subform_detail` LEFT JOIN subform ON subform_detail.subform_id=subform.subform_id RIGHT JOIN form_data_details ON subform_detail.subform_detail_id =form_data_details.subform_detail_id where subform_detail.subform_id= :subform_id and form_data_details.form_data_id = :form_data_id ORDER BY `form_data_details`.`entry_time` ASC");  
                                     $stmt2->bindParam(":subform_id",$row['subform_id']);
                                     $stmt2->bindParam(":form_data_id",$form_data_id);
                                     $stmt2->execute();
                                      if($stmt2->rowCount() > 0){
                                        ?>
                                        <tbody>
                                        <tr>
                                        <td><?php echo $time;?></td>
                                        <?php
                                        $row2=$stmt2->fetch();
                                        //  $form_data_id=$row1['form_data_id'];
                                          
                                        // echo '<script type="text/javascript">alert("Execute Javascript Function Through PHP");</script>';
                                         ?>
                                              <tr><td><input type="text" value="<?php echo $row2["entry_time"];?>" class="form-control mt-1" name="time" disabled></td>
                                              <input type="hidden" value="<?php echo $row2['form_data_details_id'];?>" class="form-control mt-1" name="form_data_details_id[]">
                                      <?php
                                      ?>
                                      <td><input type="text" value="<?php echo $row2["form_data_value"];?>" class="form-control mt-1" name="form_data_value[]"></td>
                                     <?php
                                      //echo '<td> '.$row2['form_data_value'].'</td>';
                                      $entry=$row2['entry_time'];
                                        while ($row2=$stmt2->fetch())
                                        {
                                            ?>
                                            <input type="hidden" value="<?php echo $row2["form_data_details_id"];?>" class="form-control mt-1" name="form_data_details_id[]">
                                <?php
                                            if($row2['entry_time']==$entry){
                                                ?>
                                                 <td><input type="text" value="<?php echo $row2["form_data_value"];?>" class="form-control mt-1" name="form_data_value[]"></td>
                                                <?php
                                            }
                                            else{
                                                ?>
                                                 <tr>
                                                 <td><input type="text" value="<?php echo $row2["entry_time"];?>" class="form-control mt-1" name="time" disabled></td>
                                                    <td><input type="text" value="<?php echo $row2["form_data_value"];?>" class="form-control mt-1" name="form_data_value[]"></td>
                                                <?php
                                                $entry=$row2['entry_time'];
                                            }
                                            
                                        }
                                      }
                                    }

                                        ?>
                                    
                                            </tr>                                          
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <?php
            }  
        }
        ?>
                    <div class="col-sm-12">
                        <div class="card">
                        <div class="card-header">
                        <h5>Remarks</h5>
                    </div>
                            <div class="col-md-6"> <br><?php
                            if($_SESSION["role"]==0)
                            {  
                                ?>
                                <div class="form-group row">
                                   <label for="inputEmail3" class="col-sm-3 col-form-label"><b>Morning</b> </label>
                                   <div class="col-sm-9">
                                   <input  type="text" value="<?php echo $remarks1;?>" style="width:1100px ;" class="form-control"  name="remarks1">
                                   </div>
                                </div>
                                <div class="form-group row">
                                   <label for="inputEmail3" class="col-sm-3 col-form-label"><b>Evening</b> </label>
                                   <div class="col-sm-9">
                                   <input  type="text" value="<?php echo $remarks2;?>" style="width:1100px ;" class="form-control"  name="remarks2">
                                   </div>
                                </div>
                                <div class="form-group row">
                                   <label for="inputEmail3" class="col-sm-3 col-form-label"><b>Night</b> </label>
                                   <div class="col-sm-9">
                                   <input  type="text" value="<?php echo $remarks3;?>" style="width:1100px ;" class="form-control"   name="remarks3">
                                   </div>
                                </div>
                                <?php
                            }
                            else{                          
                            ?>
                                <div class="form-group row">
                                   <label for="inputEmail3" class="col-sm-3 col-form-label"><b>Morning</b> </label>
                                   <div class="col-sm-9">
                                   <input  type="text" style="width:1100px ;" class="form-control" id="time" placeholder="Remarks" name="remarks1">
                                   </div>
                                </div>
                                <div class="form-group row">
                                   <label for="inputEmail3" class="col-sm-3 col-form-label"><b>Evening</b> </label>
                                   <div class="col-sm-9">
                                   <input  type="text" style="width:1100px ;" class="form-control" id="time" placeholder="Remarks" name="remarks2">
                                   </div>
                                </div>
                                <div class="form-group row">
                                   <label for="inputEmail3" class="col-sm-3 col-form-label"><b>Night</b> </label>
                                   <div class="col-sm-9">
                                   <input  type="text" style="width:1100px ;" class="form-control" id="time" placeholder="Remarks" name="remarks3">
                                   </div>
                                </div>
                                <?php }?>
                                 <div class="form-group row">
                                   <div class="col-sm-10">
                                       <button name="add" type="submit" class="btn  btn-primary">Submit</button>
                                   </div>
                                </div>
                            </div>
                        </div>   
                    </div>

                    <?php
            
}
?>
<?php 
include ("../includes/footer.php");
?>


<?php
if(isset($_POST["add"])){
    date_default_timezone_set("Asia/Karachi");
    $count=count($_POST["form_data_details_id"]);
$form_data_details_id=$_POST["form_data_details_id"];
$value=$_POST["form_data_value"];
$remarks1=$_POST["remarks1"];
$remarks2=$_POST["remarks2"];
$remarks3=$_POST["remarks3"];
$edited_by=$_SESSION["ffbladmin_id"];
$status=0;

//, data_status=:status, edited_by=:edited_by
//$stmt->bindParam(":status",$status);
//$stmt->bindParam(':edited_by',$edited_by);
$stmt=$conn->prepare("UPDATE `form_data` SET  data_status=:status, remarks1=:remarks1, remarks2=:remarks2,remarks3=:remarks3, edited_by=:edited_by WHERE form_data_id=:form_data_id ");
    $stmt->bindParam(":status",$status);
    $stmt->bindParam(":remarks1",$remarks1);
    $stmt->bindParam(":remarks2",$remarks2);
    $stmt->bindParam(":remarks3",$remarks3);
    $stmt->bindParam(':edited_by',$edited_by);
    $stmt->bindParam(":form_data_id",$form_data_id);
    if($stmt->execute())
    {
        for ($i=0; $i <$count ; $i++) { 
   
            $stmt=$conn->prepare("UPDATE `form_data_details` SET form_data_value=:value WHERE form_data_details_id=:form_data_details_id ");
            $stmt->bindParam(":value",$value[$i]);
            $stmt->bindParam(":form_data_details_id",$form_data_details_id[$i]);
            $stmt->execute();
            }
            ?>
            <script>
            alert("Updated Successfully");
                    //alert("Patient added successfully");
            
                    window.location.href="index.php";
          </script>
        <?php
    }

}
    ?>

