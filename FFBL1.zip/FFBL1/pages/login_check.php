<?php
if(isset($_POST["submit"])){
    include "../includes/connect.php";
$email=$_POST["email"];
$pass=$_POST["password"];
echo $email."/".$pass;
$status=1;
 //
        if(!is_null($email) && !is_null($pass))
        {
            try{
              
                global $conn;
    $stmt_login = $conn->prepare("SELECT * FROM admin WHERE name=:email AND status=:status");
                $stmt_login->bindParam(":email",$email);
				$stmt_login->bindParam(":status",$status);
                $stmt_login->execute();
                $result = $stmt_login->fetch();
                
            if(password_verify($pass, $result["password"]))
                {
                	//echo $email." ".$pass;
                   session_start();
                   // my_session_regenerate_id();
                    $_SESSION['ffbladmin_id'] = $result['admin_id'];
                    $_SESSION["name"]=$result['name'];
                    $_SESSION["role"]=$result['adminrole'];
                    $conn = null;
                    $stmt_login = null;
                    echo "succes";
                    header("Location: index.php");

                }
                else
                {
                    echo $pass;
                	// $msg="invalid password";
                    $conn = null;
                    $stmt_login = null;

                   // header("Location: login.php?invalid");
                   
                }
                
                //
            }
            catch(PDOException $e)
            {
              //echo $e;
                //header("Location: login.php?invalid");
            	$msg="Invalid User Name And Password";
            }
        }
        else
        {
               //header("Location: login.php?empty");
                $msg="Please Enter Values";
        }
        // 
}else{
	header("Location: login.php");
}
?>