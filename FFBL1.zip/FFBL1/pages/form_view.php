<?php 
$title="Forms Details";
include ("../includes/header.php");
include ("../includes/function.php");
?>
     <!-- [ Main Content ] start -->
     <div class="row">
           
           <?php 
           if(($_SESSION["role"])!= 2)
                               {
                              ?>
                              <div class="col-xl-12">
                <div class="card">
                    <div class="card-header">
                        <h5>Forms Details </h5>
                        <span class="d-block m-t-5"></span>
                    </div>
                    <div class="card-body table-border-style">
                        <div class="table-responsive">
                            <table class="table table-hover">
                                              <thead>
                                                  <tr>
                                                      <th>S-No</th>
                                                      <th>Form Name</th>
                                                      <th>Status</th>                                                      
                                                      <th>Form Type</th>
                                                      <th>Created By</th>
                                                      <th>Created Date</th>
                                                      <th class="text-right">Add Sub form</th>
                                                      <th class="text-right">Edit</th>
                                                      <th class="text-right">View</th>
                                                  </tr>
                                              </thead>
                                              <tbody>
                                             <?php 
                                            date_default_timezone_set("Asia/Karachi");
                                            $date=date("Y-m-d");
                                            $stmt=$conn->prepare("SELECT  form.* , admin.name ,`form_type`.`type_name` FROM `form` LEFT JOIN admin ON form.created_by=admin.admin_id LEFT JOIN form_type ON form.type_id=form_type.type_id ");  
                                             $stmt->execute();
                                            if($stmt->rowCount() > 0){
                                                $i=1;
                                               // echo '<script>alert("Error in Insertion");</script>';
                                                while ($row=$stmt->fetch())
                                                {
                                                    ?>
                                                                       <tr>
                                                                        <td><?php echo $i ;?></td>
                                                                                <td><?php echo $row["form_name"];?></td>
                                                                                <td><?php if($row["status"] == 1){
                                                                                    echo "Enable";}
                                                                                    else
                                                                                    {
                                                                                        echo "Disaple";}
                                                                                    ?></td> 
                                                                                    <td><?php echo $row["type_name"];?></td>
                                                                                    
                                                                                    <td><?php echo $row["name"];?></td>
                                                                                    <td><?php echo $row["created_date"];?></td>
                                                                                <td class="text-right"><a class="btn  btn-primary" href="add_subform.php?f_id=<?php echo $row["form_id"];?>">Add </a>
                                                                              </td>
                                                                              <td class="text-right"><a class="btn  btn-primary" href="edit_form.php?f_id=<?php echo $row["form_id"];?>">Edit</a>
                                                                              </td>
                                                                              <td class="text-right"><a class="btn  btn-primary" href="subform_details.php?f_id=<?php echo $row["form_id"];?>">View</a>
                                                                              </td>
                                                                            </tr>
                                             <?php
                                              
                                              $i++;  }
                                            }
                                             
                                             ?>
                                              </tbody>
                                          </table>
                                      </div>
                                  </div>
                              </div>
                                            </div>
                                            
                                            <?php
                               }
                               ?>
            
           
        </div>

<?php 
include ("../includes/footer.php");
?>