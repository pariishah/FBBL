<?php 
$title="Add Sub Forms";
include ("../includes/header.php");

include "../includes/function.php";
$role=$_SESSION["role"];
$formid=0;
if(isset($_GET["f_id"] )){
    $formid=$_GET["f_id"];
}
?>

<div class="row">

     <div class="col-sm-12">
        <div class="card">
                    <div class="col-md-6">
                                <h5 class="mt-5">Please Enter Sub Forms Details</h5>
                                <hr>
                                <form rol="form" method="post">
                                   <?php
                                   if($formid!=0){
                                   ?> 
                                   <input required type="hidden" value="<?php echo $formid;?>" name="f_id"><?php
                                   }
                                   else{                                   
                                    ?>
                                <div class="form-group row">
                                        <label for="inputEmail3" class="col-sm-3 col-form-label">Form </label>
                                        <div class="col-sm-9">
                                        <select required class="form-control" id="exampleFormControlSelect1" name="f_id">
                                        <option value="">----Select----</option>
                                         <?php
                                         getform();
                                      
                                         ?>
                                        </select>
                                        </div>
                                    </div>
                                    <?php
                                    }
                                    ?>
                                    <div class="form-group row">
                                        <label for="inputEmail3" class="col-sm-3 col-form-label">Sub Form Name</label>
                                        <div class="col-sm-9">
                                            <input required type="text" class="form-control" id="inputEmail3" placeholder="Name" name="name">
                                        </div>
                                    </div>
                                   
                                   
                                    <div class="form-group row">
                                        <label for="inputPassword3" class="col-sm-3 col-form-label">Status</label>
                                        <div class="col-sm-9">
                                            <select required class="form-control" id="exampleFormControlSelect1" name="status">
                                        <option value="">-----Select-----</option>
                                         <option value="1">Enable</option>
                                            <option value="0">Disaple</option>
                                        </select>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <div class="col-sm-10">
                                            <button name="submit" type="submit" class="btn  btn-primary">Submit</button>
                                        </div>
                                    </div>
                                </form>
                            </div>

                            
        </div>
     </div>
</div>
                






<?php 
include ("../includes/footer.php");
if(isset($_POST["submit"])){
    
    date_default_timezone_set("Asia/Karachi");
$name=$_POST["name"];
$f_id=$_POST["f_id"];
$status=$_POST["status"];
$date=date("Y-m-d");
$created_by=$_SESSION["ffbladmin_id"];

if($name!="" && $f_id!="" && $status!=""){
   
    $fstmt=$conn->prepare("INSERT INTO subform(`form_id`,`subform_name`,`status`,`created_by`,`created_date`) VALUES(:form_id,:name,:status,:created_by,:created_date)");
    $fstmt->bindParam(':form_id',$f_id);
    $fstmt->bindParam(':name',$name);    
    $fstmt->bindParam(':status',$status);
    $fstmt->bindParam(':created_by',$created_by);
    $fstmt->bindParam(':created_date',$date);
        if($fstmt->execute()){
            echo '<script>alert("Sub Form Added Successfully");</script>';
            $subform_id = $conn->lastInsertId();
            //echo '<script>alert("'. $subform_id.'");</script>';
            echo "<script>
            window.open('add_subform_detail.php?subform_id=".$subform_id."');
            </script>";
            
        }else{
            echo '<script>alert("Error in Insertion");</script>';
            
        }
}   
    
else{
    ?>
    <script>alert("Please Complete Form!");</script>
    <?php
}
}
else{
    ?>
    <script>//alert("Form!");</script>
    <?php
}
?>


