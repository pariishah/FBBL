<?php 
$title="Add Sub Forms details";
include ("../includes/header.php");

include "../includes/function.php";
$role=$_SESSION["role"];
?>

<div class="row">

     <div class="col-sm-12">
        <div class="card">
                    <div class="col-md-6">
                                <h5 class="mt-5">Please Enter Details</h5>
                                <hr>
                                <form rol="form" method="post">
                               
                                    <div class="form-group row">
                                        <label for="inputEmail3" class="col-sm-3 col-form-label">Description 1</label>
                                        <div class="col-sm-9">
                                            <input required type="text" class="form-control" id="inputEmail3" placeholder="Description" name="description1">
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="inputEmail3" class="col-sm-3 col-form-label">Description 2</label>
                                        <div class="col-sm-9">
                                            <input required type="text" class="form-control" id="inputEmail3" placeholder="Description" name="description2">
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="inputEmail3" class="col-sm-3 col-form-label">BMR value</label>
                                        <div class="col-sm-9">
                                            <input  type="text" class="form-control" id="inputEmail3" placeholder="BMR" name="bmr">
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="inputEmail3" class="col-sm-3 col-form-label">Operating Range</label>
                                        <div class="col-sm-9">
                                            <input  type="text" class="form-control" id="inputEmail3" placeholder="Range" name="range">
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="inputPassword3" class="col-sm-3 col-form-label">Status</label>
                                        <div class="col-sm-9">
                                            <select required class="form-control" id="exampleFormControlSelect1" name="status">
                                        <option value="">-----Select-----</option>
                                         <option value="1">Enable</option>
                                            <option value="0">Disaple</option>
                                        </select>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <div class="col-sm-10">
                                            <button name="submit" type="submit" class="btn  btn-primary">Submit</button>
                                        </div>
                                    </div>
                                </form>
                            </div>

                            
        </div>
     </div>
</div>
                






<?php 
include ("../includes/footer.php");
if(isset($_POST["submit"])){
    
    date_default_timezone_set("Asia/Karachi");
$description1=$_POST["description1"];
$description2=$_POST["description2"];
$bmr=$_POST["bmr"];
$range=$_POST["range"];
$sub_id=$_GET["subform_id"];
$status=$_POST["status"];
$date=date("Y-m-d");
$created_by=$_SESSION["ffbladmin_id"];

if($description1!="" && $description2!="" && $status!=""){
   // echo '<script>alert("'.$sub_id.$description1.$description2.$bmr.$range.'");</script>';
    $fstmt=$conn->prepare("INSERT INTO subform_detail(`subform_id`,`description1`,`description2`,`bmr`,`range`,`status`,`created_by`,`created_date`) VALUES(:sub_id,:description1,:description2,:bmr,:range,:status,:created_by,:created_date)");
    $fstmt->bindParam(':sub_id',$sub_id);
    $fstmt->bindParam(':description1',$description1); 
    $fstmt->bindParam(':description2',$description2); 
    $fstmt->bindParam(':bmr',$bmr); 
    $fstmt->bindParam(':range',$range);    
    $fstmt->bindParam(':status',$status);
    $fstmt->bindParam(':created_by',$created_by);
    $fstmt->bindParam(':created_date',$date);
        if($fstmt->execute()){
            echo '<script>alert("Details Added Successfully");</script>';
           // $subform_id = $conn->lastInsertId();
            //echo '<script>alert("'. $subform_id.'");</script>';
            
            
        }else{
            echo '<script>alert("Error in Insertion");</script>';
            
        }
}   
    
else{
    ?>
    <script>alert("Please Complete Form!");</script>
    <?php
}
}
else{
    ?>
    <script>//alert("Form!");</script>
    <?php
}
?>


