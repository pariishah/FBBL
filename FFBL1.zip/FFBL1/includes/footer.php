</div>
</div>
    <script src="../assets/js/vendor-all.min.js"></script>
    <script src="../assets/js/plugins/bootstrap.min.js"></script>
    <script src="../assets/js/pcoded.min.js"></script>

  <!-- Apex Chart -->
 <script src="../assets/js/plugins/apexcharts.min.js"></script>


 <!-- custom-chart js -->
 <script src="../assets/js/pages/dashboard-main.js"></script>
 </body>

</html>