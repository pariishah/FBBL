<?php
include "connect.php";
function logout()
{
   // session_start();
    session_unset();
    session_destroy(); 
   // my_session_regenerate_id();
   echo "function";
    header("Location: ../pages/login.php");
}
function getform()
{
    global $conn;
    $status=1;
    $stmt=$conn->prepare("SELECT * FROM `form` where status=:status; ");  
    $stmt->bindParam(":status",$status);
    $stmt->execute();
    if($stmt->rowCount() > 0){
        while ($row=$stmt->fetch())
        {
            ?>
                <option value="<?php echo $row["form_id"];?>"><?php echo $row["form_name"] ;?></option>
                
                
            <?php
            
        }
    }
}
function getformtype()
{
    global $conn;
    $stmt=$conn->prepare("SELECT * FROM `form_type` ");  
    $stmt->execute();
    if($stmt->rowCount() > 0){
        while ($row=$stmt->fetch())
        {
            ?>
                <option value="<?php echo $row["type_id"];?>"><?php echo $row["type_name"] ;?></option>
                
                
            <?php
            
        }
    }
}
function getforms_for_admin(){
    global $conn;
    date_default_timezone_set("Asia/Karachi");
    $date=date("Y-m-d");
    $stmt=$conn->prepare("SELECT  form.form_id,form_name , form_data.* FROM `form_data` LEFT JOIN form ON form_data.form_id=form.form_id  where form_data.created_date = :created_date");  
    $stmt->bindParam(':created_date',$date);
     $stmt->execute();
    if($stmt->rowCount() > 0){
        $i=1;
       // echo '<script>alert("Error in Insertion");</script>';
        while ($row=$stmt->fetch())
        {
            ?>
                               <tr>
                                <td><?php echo $i ;?></td>
                                        <td><?php echo $row["form_name"];?></td>
                                        <td><?php if($row["data_status"] == 1){
                                            echo "Draft";}
                                            else
                                            {
                                                echo "Verified";}
                                            ?></td>                                        
                                        <td class="text-right"><a class="btn  btn-primary" href="update_formdata.php?f_id=<?php echo $row["form_id"];?>&& form_name=<?php echo $row["form_name"];?>&&form_data_id=<?php echo $row["form_data_id"];?>">click</a>
                                      </td>
                                    </tr>
     <?php
      
      $i++;  }
    }
    
}
function getforms_for_eng(){
    global $conn;
    date_default_timezone_set("Asia/Karachi");
    $status=1;//SELECT vechile_routes.*,vechile.Company,vechile_type,cities.city_name FROM `vechile_routes` LEFT JOIN vechile ON vechile_routes.vechile_id=vechile.vechile_id LEFT JOIN cities ON vechile_routes.from_city=cities.city_id WHERE vechile.Company=:company
    $date=date("Y-m-d");
    $stmt=$conn->prepare("SELECT  form.form_id,form_name , form_data.* FROM `form_data` LEFT JOIN form ON form_data.form_id=form.form_id  where form_data.created_date = :created_date AND form_data.data_status = :status");  
    $stmt->bindParam(':created_date',$date);
    $stmt->bindParam(':status',$status);
     $stmt->execute();
    if($stmt->rowCount() > 0){
        $i=1;
       // echo '<script>alert("Error in Insertion");</script>';
        while ($row=$stmt->fetch())
        {
            ?>
                               <tr>
                                <td><?php echo $i ;?></td>
                                        <td><?php echo $row["form_name"];?></td>
                                        <td><?php if($row["data_status"] == 1){
                                            echo "Draft";}
                                            else
                                            {
                                                echo "Verified";}
                                            ?></td>                                        
                                        <td class="text-right"><a class="btn  btn-primary" href="update_formdata.php?f_id=<?php echo $row["form_id"];?>&&data_no=<?php echo $row["data_no"];?>">click</a>
                                      </td>
                                    </tr>
     <?php
      
      $i++;  }
    }
}
function getforms_for_opertor(){
   
}
function getform_data_no($count)
{
    global $conn;
   // $cargo_no=$t_id.$day.$mint;
    $stmt=$conn->prepare("SELECT form_data_id FROM `form_data` ORDER BY `form_data`.`form_data_id` DESC; ");  
    $stmt->execute();
    if($stmt->rowCount() > 0){
        $row=$stmt->fetch();
       // $row++;
        $id=$row['form_data_id'];

        $id++;
        $inc=$id;
        for ($i=1;$i<$count;$i++)
        {
            $inc++;  
        }
        $id.=$inc;
        return $id;
    }
}
?>